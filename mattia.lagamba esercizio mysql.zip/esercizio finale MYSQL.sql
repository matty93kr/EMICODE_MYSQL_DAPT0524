CREATE DATABASE TOYSGROUP;

CREATE TABLE Category (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(50) NOT NULL
);

CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    CategoryID INT,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID));
    
    CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(50) NOT NULL
);

CREATE TABLE Country (
    CountryID INT PRIMARY KEY,
    CountryName VARCHAR(50) NOT NULL,
    RegionID INT,
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
    Date DATE,
    Quantity INT,
    Amount DECIMAL(10, 2),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

INSERT INTO Category (CategoryID, CategoryName)
VALUES 
    (1, 'PowerRangers'),
    (2, 'Manga');
    

INSERT INTO Region (RegionID, RegionName)
VALUES 
    (1, 'WestEurope'),
    (2, 'SouthEurope');
    
    INSERT INTO Country (CountryID, CountryName, RegionID)
VALUES 
    (10, 'France', 1),
    (11, 'Germany', 1),
    (20, 'Italy', 2),
    (21, 'Greece', 2);
    
 INSERT INTO Sales (SalesID, ProductID, RegionID, Date, Quantity, Amount)
VALUES 
    (1001, 101, 1, '2024-01-15', 10, 150.00),
    (1002, 102, 2, '2024-02-10', 5, 80.00),
    (1003, 201, 1, '2024-03-05', 10, 30.00),
    (1004, 202, 2, '2024-04-20', 15, 45.00);
        
  -- task 4 esercizio N1      
        
    SELECT 
    COUNT(DISTINCT CategoryID) = COUNT(CategoryID) AS CategoryPKUnique
FROM
    Category;
    
    
SELECT 
    COUNT(DISTINCT ProductID) = COUNT(ProductID) AS ProductPKUnique
FROM
    Product;
SELECT 
    COUNT(DISTINCT RegionID) = COUNT(RegionID) AS RegionPKUnique
FROM
    Region;
SELECT 
    COUNT(DISTINCT StateID) = COUNT(CountryID) AS countryPKUnique
FROM
    country;
SELECT 
    COUNT(DISTINCT salesID) = COUNT(salesID) AS SalesPKUnique
FROM
    Sales;
    
-- task 4 esercizio N3

SELECT 
    P.ProductName AS 'product_name',
    SUM(S.Quantity) AS 'Tot_sales'
FROM 
    Sales S
JOIN 
    Product P ON S.ProductID = P.ProductID
WHERE 
    S.Date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY 
    P.ProductName
HAVING 
    SUM(S.Quantity) > (
        SELECT 
            AVG(TotalQuantity) 
        FROM (
            SELECT 
                SUM(Quantity) AS TotalQuantity
            FROM 
                Sales
            WHERE 
                Date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
            GROUP BY 
                DATE(Date)
        ) AS AvgSales
    );
    
    -- task 4 esercizio N2
     
    SELECT 
    S.SalesID AS 'Codice Documento',
    S.Date AS 'Data',
    P.ProductName AS 'Nome Prodotto',
    C.CategoryName AS 'Categoria Prodotto',
    CO.CountryName AS 'Nome Stato',
    R.RegionName AS 'Nome Regione',
    CASE 
        WHEN DATEDIFF(CURDATE(), S.Date) > 180 THEN 'TRUE'
        ELSE 'False' 
        END 'vero o falso'
FROM Sales S
JOIN 
    Product P ON S.ProductID = P.ProductID
JOIN 
    Category C ON P.CategoryID = C.CategoryID
JOIN 
    Region R ON S.RegionID = R.RegionID
JOIN 
    Country CO ON R.RegionID = CO.RegionID;
    
-- task 4 esercizio N4
    
  SELECT 
    p.ProductID, 
    p.ProductName, 
    s.Date, 
    SUM(s.Amount) AS fatturato_totale_annuale
FROM 
    product p
JOIN 
     sales s ON p.ProductID = s.ProductID
GROUP BY 
    p.ProductID, p.ProductName, s.Date;

  -- task 4 esercizio N5
  
SELECT 
    C.CountryName AS State,
    YEAR(S.Date) AS anno,
    SUM(S.Amount) AS Fatturato_Totale
FROM 
    Sales S
JOIN 
    country C ON S.RegionID = c.RegionID
GROUP BY 
    C.CountryName, YEAR(S.Date)
ORDER BY 
    anno, Fatturato_Totale DESC;
    
    -- task 4 esercizio N6
    
    SELECT 
    C.CategoryName,
    SUM(S.Quantity) AS Tot_sales
FROM 
    Sales S
JOIN 
    Product P ON S.ProductID = P.ProductID
JOIN 
    Category C ON P.CategoryID = C.CategoryID
GROUP BY 
    C.CategoryName
ORDER BY 
    Tot_sales DESC
LIMIT 1;

-- task 4 esercizio N7

SELECT 
    p.ProductID, 
    p.ProductName
FROM 
    product p
LEFT JOIN 
    sales s ON p.ProductID = s.ProductID
WHERE 
    s.ProductID IS NULL;
    
    -- task 4 esercizio N8
    
    SELECT 
    ProductID
    ProductName
FROM 
    product
WHERE 
    quantity = 0;
    -- Non appare nulla perchè non ho inserito prodotti non venduti e colonna quantity in product
    
    -- task 4 esercizio N9
    
  CREATE VIEW Product_view AS
SELECT 
    p.ProductID, 
    p.ProductName, 
    c.CategoryName
FROM 
    product p
JOIN 
    category c ON p.CategoryID = c.CategoryID;

-- task 4 esercizio N10

 CREATE VIEW geographic_view AS
    SELECT 
        CountryID, CountryName, RegionID
    FROM
        country;

    
   
    

    
    

    
    

    




   
    
    